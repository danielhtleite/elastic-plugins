"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("react/jsx-runtime");
const eui_1 = require("@elastic/eui");
function Fieldset({ legend, children, style }) {
    return (
    // @ts-ignore
    (0, jsx_runtime_1.jsx)(eui_1.EuiFormFieldset, { legend: legend, style: style, children: children }));
}
exports.default = Fieldset;
