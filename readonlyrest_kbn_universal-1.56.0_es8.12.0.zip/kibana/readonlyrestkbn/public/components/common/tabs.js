"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Tabs = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
const eui_1 = require("@elastic/eui");
function Tabs({ children, display = 'default', expand = false, size = 'm' }) {
    return ((0, jsx_runtime_1.jsx)(eui_1.EuiTabs, { display: display, expand: expand, size: size, children: children }));
}
exports.Tabs = Tabs;
