"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("react/jsx-runtime");
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
const eui_1 = require("@elastic/eui");
function Search({ placeholder, value, isClearable, onChange, style, autoFocus }) {
    return (
    // @ts-ignore
    (0, jsx_runtime_1.jsx)(eui_1.EuiFieldSearch, { ref: ref => {
            /**
             * We need this workaround to make autofocus work, looks like we need to wait for fully rendered menu,
             * and push focus method as the last call stack element
             */
            if (ref?.inputElement && autoFocus) {
                setTimeout(() => {
                    ref.inputElement?.focus();
                }, 100);
            }
        }, placeholder: placeholder, value: value, isClearable: isClearable, onChange: onChange, 
        // @ts-ignore
        style: style }));
}
exports.default = Search;
