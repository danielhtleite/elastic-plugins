/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */

(function activationKeyExpirationAlertScope() {
  const POPUP_THRESHOLD_IN_DAYS = 33;
  const KEY_EXPIRATION_DATE = Number.parseInt('${expirationDateEpoch}', 10);
  const IS_TRIAL = 'true' === '${isTrial}';
  const IGNORE_ACTIVATION_KEY_COOKIE_NAME = 'rorIgnoreActivationKeyInfo';

  function getCookie(cookieName) {
    let cookieNameX;
    let cookieNameY;
    const cookiesList = document.cookie.split(';');
    for (let i = 0; i < cookiesList.length; i++) {
      cookieNameX = cookiesList[i].substr(0, cookiesList[i].indexOf('='));
      cookieNameY = cookiesList[i].substr(cookiesList[i].indexOf('=') + 1);
      cookieNameX = cookieNameX.replace(/^\s+|\s+$/g, '');
      if (cookieNameX === cookieName) {
        return unescape(cookieNameY);
      }
    }
  }

  function setCookie(cookieName, value, hours) {
    const expirationDate = new Date();
    expirationDate.setHours(expirationDate.getHours() + hours);

    const cookieValue = escape(value) + (hours ? `; expires=${expirationDate.toUTCString()}` : '');
    document.cookie = `${cookieName}=${cookieValue}; path=/`;
  }

  // a function that takes epoch seconds and returns the number of days until now
  function daysUntilNow(epochSeconds) {
    const A_DAY_IN_MILLISECONDS = 1000 * 60 * 60 * 24;
    const now = new Date();
    const then = new Date(0);
    then.setUTCSeconds(epochSeconds);
    const diff = then - now;
    return Math.ceil(diff / A_DAY_IN_MILLISECONDS);
  }

  function init(keyExpirationDate, isTrial) {
    const DAYS_UNTIL_KEY_EXPIRATION = daysUntilNow(keyExpirationDate);

    /**
     * We need to add sessionStorage ignoreKeyExpirationInfo for automatic tests purposes as a workaround of https://github.com/cypress-io/cypress/issues/4158
     * When we reload a page, for example on tenancy change, cypress is not able to close alert automatically and, we cannot do it programmatically
     * since the window browser object changed, and we are not able to subscribe to specific onAlert event. The result is, that tests hung, and we need to close the alert manually
     * What is not the best option in case of automatic tests
     */
    const manuallyIgnoreAlert = sessionStorage.getItem('ror:ignoreKeyExpirationInfo') === 'true';

    const ignoreActivationKeyCookie = getCookie(IGNORE_ACTIVATION_KEY_COOKIE_NAME) === 'true';
    const showExpirationAlert =
      DAYS_UNTIL_KEY_EXPIRATION < POPUP_THRESHOLD_IN_DAYS && !manuallyIgnoreAlert && !ignoreActivationKeyCookie;

    const message = isTrial
      ? `ReadonlyREST plugins for Kibana are non-free. This is a time-limited but full-featured trial build for your evaluation. Visit https://readonlyrest.com for more information.`
      : `ReadonlyREST Activation Key is about to expire. Visit https://readonlyrest.com/customer to get a new Activation Key.`;
    if (showExpirationAlert) {
      setCookie(IGNORE_ACTIVATION_KEY_COOKIE_NAME, 'true', isTrial ? 6 : 24);
      window.alert(`ReadonlyREST universal build (${DAYS_UNTIL_KEY_EXPIRATION} ${
        DAYS_UNTIL_KEY_EXPIRATION > 1 ? 'days' : 'day'
      } left).\n
\n${message}\n\n
If you are already a subscriber and your payment has been received, obtain an Activation Key from https://readonlyrest.com/customer and follow the instructions to activate this software. This is a universal build, ${
        isTrial
          ? 'no need to reinstall a different plugin to upgrade licenses.'
          : 'no need to download a new plugin package to renew your subscription, or to upgrade to PRO or Enterprise editions. Just load a different Activation Key.'
      }\n`);
    }
  }

  init(KEY_EXPIRATION_DATE, IS_TRIAL);

  if (typeof module !== 'undefined' && Object.prototype.hasOwnProperty.call(module, 'exports')) {
    module.exports = {
      init,
      IGNORE_ACTIVATION_KEY_COOKIE_NAME,
      getCookie,
      setCookie
    };
  }
})();
